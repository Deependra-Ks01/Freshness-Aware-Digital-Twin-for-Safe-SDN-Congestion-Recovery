#!/usr/bin/env bash
# One-command reproducible run.
#   ./run_scenario.sh static   0      # Week-1 baseline, no rerouting
#   ./run_scenario.sh baseline 1      # Week-1 baseline, reactive reroute
# Pick the controller with APP=controller/twin_te.py (default: baseline_te.py).
# Extra args go to run_experiment.py.
set -euo pipefail
NAME=${1:?usage: $0 <name> <reroute 0|1> [run_experiment args]}
REROUTE=${2:?usage: $0 <name> <reroute 0|1> [run_experiment args]}
shift 2
APP=${APP:-controller/baseline_te.py}
VENV=${VENV:-$HOME/ryu-venv}
OUT=logs/$NAME
mkdir -p "$OUT"

sudo mn -c >/dev/null 2>&1 || true

# shellcheck disable=SC1091
source "$VENV/bin/activate"
PYTHONPATH=$PWD REROUTE=$REROUTE LOG_DIR=$OUT \
  ryu-manager "$APP" > "$OUT/ryu.log" 2>&1 &
RYU_PID=$!
trap 'kill $RYU_PID 2>/dev/null || true; sudo mn -c >/dev/null 2>&1 || true' EXIT
sleep 4

sudo /usr/bin/python3 run_experiment.py --mode experiment --out "$OUT" "$@"
echo "Done. Logs in $OUT"
